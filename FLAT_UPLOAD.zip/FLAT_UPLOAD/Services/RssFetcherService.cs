using CodeHollow.FeedReader;
using Microsoft.Extensions.Logging;
using MorsadBackend.Core.Entities;
using MorsadBackend.Core.Interfaces;

namespace MorsadBackend.Infrastructure.Services;

/// <summary>
/// يجلب الأخبار من RSS مباشرة ويحفظها في قاعدة البيانات
/// </summary>
public class RssFetcherService
{
    private readonly INewsRepository _newsRepo;
    private readonly ILookupRepository _lookupRepo;
    private readonly ILogger<RssFetcherService> _logger;

    public RssFetcherService(
        INewsRepository newsRepo,
        ILookupRepository lookupRepo,
        ILogger<RssFetcherService> logger)
    {
        _newsRepo   = newsRepo;
        _lookupRepo = lookupRepo;
        _logger     = logger;
    }

    public async Task FetchAllAsync()
    {
        var sources = await _lookupRepo.GetActiveSourcesAsync();
        var rssSources = sources.Where(s => !string.IsNullOrEmpty(s.RssUrl)).ToList();

        _logger.LogInformation("مرصاد: بدء جلب RSS من {Count} مصدر", rssSources.Count);

        foreach (var source in rssSources)
        {
            await FetchSourceAsync(source);
        }
    }

    private async Task FetchSourceAsync(NewsSource source)
    {
        try
        {
            var feed = await FeedReader.ReadAsync(source.RssUrl!);
            var newArticles = new List<NewsArticle>();

            foreach (var item in feed.Items.Take(20))
            {
                var link = item.Link ?? item.Id ?? string.Empty;
                if (string.IsNullOrEmpty(link)) continue;
                if (await _newsRepo.ExistsByLinkAsync(link)) continue;

                newArticles.Add(new NewsArticle
                {
                    SourceId    = source.Id,
                    Title       = item.Title?.Trim() ?? "(بلا عنوان)",
                    Link        = link,
                    Summary     = item.Description?.Length > 2000
                                    ? item.Description[..2000]
                                    : item.Description,
                    PublishedAt = item.PublishingDate ?? DateTime.UtcNow,
                    FetchedAt   = DateTime.UtcNow,
                    IsProcessed = false
                });
            }

            if (newArticles.Count > 0)
            {
                await _newsRepo.AddArticlesAsync(newArticles);
                await _newsRepo.SaveChangesAsync();
                _logger.LogInformation("  [{Source}] أُضيف {Count} خبر جديد", source.NameAr, newArticles.Count);
            }

            await _lookupRepo.UpdateSourceLastFetchedAsync(source.Id, DateTime.UtcNow);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "  [{Source}] فشل جلب RSS", source.NameAr);
        }
    }
}
