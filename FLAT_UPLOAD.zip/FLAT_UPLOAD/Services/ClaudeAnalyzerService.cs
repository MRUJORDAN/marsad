using System.Text.Json;
using Microsoft.Extensions.Logging;
using MorsadBackend.Core.Entities;
using MorsadBackend.Core.Interfaces;

namespace MorsadBackend.Infrastructure.Services;

/// <summary>
/// يستخدم Claude API لتصنيف الأخبار وتحليل مشاعرها
/// يستدعى عبر HttpClient مباشرة (بدون API wrapper)
/// </summary>
public class ClaudeAnalyzerService
{
    private readonly INewsRepository    _newsRepo;
    private readonly ILookupRepository  _lookupRepo;
    private readonly IRiskRepository    _riskRepo;
    private readonly HttpClient         _http;
    private readonly ILogger<ClaudeAnalyzerService> _logger;
    private readonly string             _apiKey;

    private const string MODEL = "claude-haiku-4-5-20251001";
    private const string API   = "https://api.anthropic.com/v1/messages";

    public ClaudeAnalyzerService(
        INewsRepository newsRepo,
        ILookupRepository lookupRepo,
        IRiskRepository riskRepo,
        HttpClient http,
        string apiKey,
        ILogger<ClaudeAnalyzerService> logger)
    {
        _newsRepo   = newsRepo;
        _lookupRepo = lookupRepo;
        _riskRepo   = riskRepo;
        _http       = http;
        _apiKey     = apiKey;
        _logger     = logger;
    }

    // ── تحليل الأخبار غير المصنّفة ──────────────────────────────
    public async Task AnalyzeUnprocessedAsync()
    {
        var articles = (await _newsRepo.GetUnprocessedAsync(50)).ToList();
        if (!articles.Any()) return;

        _logger.LogInformation("مرصاد: تحليل {Count} خبر بـ Claude", articles.Count);

        // نحضر الـ Lookups مرة واحدة
        var categories = (await _lookupRepo.GetMinorsByMajorCodeAsync("CATEGORY"))
                         .ToDictionary(m => m.NameAr);
        var sentiments = (await _lookupRepo.GetMinorsByMajorCodeAsync("SENTIMENT"))
                         .ToDictionary(m => m.Code);

        var titles = string.Join("\n", articles.Select((a, i) => $"{i}. {a.Title}"));

        var prompt = $@"صنّف هذه الأخبار الأردنية وحلّل مشاعرها.
لكل خبر أرجع: index، category (سياسة/اقتصاد/أمن/مجتمع/دولي/رياضة/تعليم/تكنولوجيا/بيئة/إعلام)، sentiment (SENT_POS/SENT_NEG/SENT_NEU)، confidence (0.0-1.0).
أرجع JSON فقط: {{""results"":[{{""index"":0,""category"":""سياسة"",""sentiment"":""SENT_NEU"",""confidence"":0.9}},...]}}\n\n{titles}";

        var response = await CallClaudeAsync(prompt, maxTokens: 1500);
        if (response == null) return;

        var processedIds = new List<int>();
        try
        {
            using var doc = JsonDocument.Parse(response);
            var results = doc.RootElement.GetProperty("results");

            foreach (var r in results.EnumerateArray())
            {
                var idx        = r.GetProperty("index").GetInt32();
                var catName    = r.GetProperty("category").GetString() ?? "";
                var sentCode   = r.GetProperty("sentiment").GetString() ?? "SENT_NEU";
                var confidence = r.GetProperty("confidence").GetSingle();

                if (idx >= articles.Count) continue;
                var article = articles[idx];

                if (!categories.TryGetValue(catName, out var cat)) continue;
                if (!sentiments.TryGetValue(sentCode, out var sent)) continue;

                article.Tags.Add(new ArticleTag
                {
                    ArticleId        = article.Id,
                    CategoryMinorId  = cat.Id,
                    SentimentMinorId = sent.Id,
                    ConfidenceScore  = confidence,
                    TaggedAt         = DateTime.UtcNow
                });

                processedIds.Add(article.Id);
            }

            await _newsRepo.SaveChangesAsync();
            await _newsRepo.MarkAsProcessedAsync(processedIds);
            _logger.LogInformation("  تم تحليل {Count} خبر", processedIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "خطأ في تحليل الأخبار");
        }
    }

    // ── تقييم المخاطر الأمنية ───────────────────────────────────
    public async Task AssessRisksAsync()
    {
        _logger.LogInformation("مرصاد: تقييم المخاطر الأمنية");

        var periodEnd   = DateTime.UtcNow;
        var periodStart = periodEnd.AddHours(-6);

        var riskTypes = (await _lookupRepo.GetMinorsByMajorCodeAsync("RISK_TYPE")).ToList();
        var trends    = (await _lookupRepo.GetMinorsByMajorCodeAsync("TREND"))
                        .ToDictionary(t => t.Code);

        var articles = await _newsRepo.GetTodayArticlesAsync(periodStart, periodEnd);
        var summary  = string.Join("\n", articles.Take(30).Select(a => $"- {a.Title}"));

        var prompt = $@"أنت محلل مخاطر إعلامي للمركز الوطني للأمن وإدارة الأزمات في الأردن.
بناءً على هذه الأخبار الأردنية خلال آخر 6 ساعات، قيّم مستوى كل نوع من المخاطر الإعلامية (0-100).

أرجع JSON فقط:
{{""risks"":[
  {{""code"":""RISK_FAKE"",   ""score"":52, ""trend"":""TREND_UP"",   ""topCase"":""وصف مختصر""}},
  {{""code"":""RISK_FOREIGN"",""score"":45, ""trend"":""TREND_STABLE"",""topCase"":""...""}},
  {{""code"":""RISK_HATE"",   ""score"":38, ""trend"":""TREND_DOWN"", ""topCase"":""...""}},
  {{""code"":""RISK_ECO"",    ""score"":31, ""trend"":""TREND_STABLE"",""topCase"":""...""}},
  {{""code"":""RISK_CYBER"",  ""score"":29, ""trend"":""TREND_UP"",   ""topCase"":""...""}}
]}}

الأخبار:
{summary}";

        var response = await CallClaudeAsync(prompt, maxTokens: 800);
        if (response == null) return;

        try
        {
            using var doc  = JsonDocument.Parse(response);
            var risksJson  = doc.RootElement.GetProperty("risks");
            var assessments = new List<RiskAssessment>();
            var now = DateTime.UtcNow;

            foreach (var r in risksJson.EnumerateArray())
            {
                var code      = r.GetProperty("code").GetString() ?? "";
                var trendCode = r.GetProperty("trend").GetString() ?? "TREND_STABLE";

                var riskMinor = riskTypes.FirstOrDefault(rt => rt.Code == code);
                if (riskMinor == null) continue;
                if (!trends.TryGetValue(trendCode, out var trend)) continue;

                assessments.Add(new RiskAssessment
                {
                    RiskTypeMinorId = riskMinor.Id,
                    TrendMinorId    = trend.Id,
                    Score           = r.GetProperty("score").GetSingle(),
                    TopCase         = r.GetProperty("topCase").GetString(),
                    AssessedAt      = now,
                    PeriodStart     = periodStart,
                    PeriodEnd       = periodEnd
                });
            }

            await _riskRepo.AddAssessmentsAsync(assessments);
            await _riskRepo.SaveChangesAsync();
            _logger.LogInformation("  تم حفظ {Count} تقييم مخاطر", assessments.Count);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "خطأ في تقييم المخاطر");
        }
    }

    // ── استدعاء Claude API ──────────────────────────────────────
    private async Task<string?> CallClaudeAsync(string prompt, int maxTokens)
    {
        try
        {
            var body = JsonSerializer.Serialize(new
            {
                model      = MODEL,
                max_tokens = maxTokens,
                messages   = new[] { new { role = "user", content = prompt } }
            });

            var req = new HttpRequestMessage(HttpMethod.Post, API);
            req.Headers.Add("x-api-key", _apiKey);
            req.Headers.Add("anthropic-version", "2023-06-01");
            req.Content = new StringContent(body, System.Text.Encoding.UTF8, "application/json");

            var res = await _http.SendAsync(req);
            res.EnsureSuccessStatusCode();

            var json    = await res.Content.ReadAsStringAsync();
            using var d = JsonDocument.Parse(json);
            var text    = d.RootElement
                           .GetProperty("content")[0]
                           .GetProperty("text").GetString() ?? "";

            // استخرج JSON من الرد
            var start = text.IndexOf('{');
            var end   = text.LastIndexOf('}');
            if (start < 0 || end < 0) return null;
            return text[start..(end + 1)];
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "فشل استدعاء Claude API");
            return null;
        }
    }
}
